#include "opencv2/core.hpp"
#include "opencv2/face.hpp"
#include "opencv2/highgui.hpp"
#include "opencv2/imgproc.hpp"

#include <iostream>
#include <fstream>
#ifdef __GNUC__
#include <experimental/filesystem> // Full support in C++17
namespace fs = std::experimental::filesystem;
#else
#include <filesystem>
namespace fs = std::tr2::sys;
#endif

// https://msdn.microsoft.com/en-us/library/dn986850.aspx
// GCC 5.2.1 Ok on Linux
// g++ -std=c++11 facerec.cpp -lstdc++fs


int main(int argc, char *argv[])
{
  std::vector<cv::Mat> images;
  std::vector<int>     labels;

  // Iterate through all subdirectories, looking for .pgm files
  fs::path p(argc > 1 ? argv[1] : "../att_faces");
  for (const auto &entry : fs::recursive_directory_iterator{ p }) {
   // if (fs::is_regular_file(entry.status())) {
      if (entry.path().extension() == ".pgm") {
        std::string str = entry.path().parent_path().stem().string(); // s26 s27 etc.
        int label = atoi(str.c_str() + 1); // s1 -> 1
        images.push_back(cv::imread(entry.path().string().c_str(), 0));
        labels.push_back(label);
      }
    //}
  }

  cv::Mat frame;
  double fps = 60;
  const char win_name[] = "Live Video...";

  cv::VideoCapture vid_in(0);   // argument is the camera id
  if (!vid_in.isOpened()) {
	  std::cout << "error: Camera 0 could not be opened for capture.\n";
	  exit(0);
  }

  cv::namedWindow(win_name);

  // Randomly choose an image, and remove it from the main collection
  std::srand(std::time(0));
  int rand_image_id = std::rand() % images.size();
  cv::Mat testSample = images[rand_image_id];
  int     testLabel  = labels[rand_image_id];
  images.erase(images.begin() + rand_image_id);
  labels.erase(labels.begin() + rand_image_id);
  std::cout << "Actual class    = " << testLabel << '\n';
  std::cout << " training...";

  cv::Ptr<cv::face::BasicFaceRecognizer> model = cv::face::createEigenFaceRecognizer();
  model->train(images, labels);
  int predictedLabel, newLabel, resizeW = 92, resizeH = 112;
  cv::Mat copyFrame, greyFrame, greySizedFrame;
  //insert loop here
  while (1) {
	  vid_in >> frame;
	  copyFrame = frame.clone();
	  cvtColor(copyFrame, greyFrame, cv::COLOR_RGB2GRAY);
	  resize(greyFrame, greySizedFrame, cv::Size(resizeW, resizeH), 1.0, 1.0, cv::INTER_CUBIC);
	  imshow(win_name, greySizedFrame);
	  if (cv::waitKey(1000 / fps) == 27) // escape
		  break;
	  predictedLabel = model->predict(greySizedFrame);

	  // To get the confidence of a prediction call the model with:
	  //
	  //      int predictedLabel = -1;
	  //      double confidence = 0.0;
	  //      model->predict(testSample, predictedLabel, confidence);
	  if (predictedLabel != testLabel)
		std::cout << "\nPredicted class = " << predictedLabel << '\n';
  }
  
  vid_in.release();
  return 0;
}

#pragma once
#define NOT_VISITED 0;
#define VISITED 1;


class Position {
public:
	int x = 0, y = 0;
//public:
	bool equals(Position pos) {
		return ((x == pos.x) && (y == pos.y));
	}
};

class Node {
private:
	int value = 0;
	Position pos;
	//int posx = 0, posy = 0;
	int state = NOT_VISITED;
public:
	void setValue(int v);
	void setPosition(int x, int y);
	Position getPosition();
	void getNeighbours(class DOTGraph graph, Node n[], int w[]);
};

namespace std {
	template<>
	struct hash<Node> {
		inline size_t operator()(const Position& pos) const {
			int x = pos.x, y = pos.y;
			return x * 1812433253 + y;
		}
	};
}

struct Edge {
	int weight = 0;
	Node connected[2];
};

class DOTGraph {
public:
	Node nodes[64];
	Edge edges[128];

	Node neighbours[4];
//public:
	DOTGraph();
	void parseDOT();
	void setNodePos(int x, int y);
	void setEdge(int con1, int con2, int w);
	Node getNode(int i);
	//void getNeighbours(Node current);
};

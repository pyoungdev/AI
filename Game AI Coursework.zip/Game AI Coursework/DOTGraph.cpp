#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
#include "DOTGraph.h"
using namespace std;

void Node::setValue(int v) {
	value = v;
}

void Node::setPosition(int x, int y) {
	pos.x = x;
	pos.y = y;
}

Position Node::getPosition() {
	return pos;
}

DOTGraph::DOTGraph() {
	for (int i = 0; i < 64; i++)
		nodes[i].setValue(i);
}

void DOTGraph::setNodePos(int x, int y) {
	int i = 0;
	while (nodes[i].getPosition().x != 0) {
		i++;
	}
	nodes[i].setPosition(x, y);
	//nodes[i].posx = x;
	//nodes[i].posy = y;
}

void DOTGraph::setEdge(int con1, int con2, int w) {
	int i = 0;
	while (edges[i].weight != 0) {
		i++;
	}
	edges[i].connected[0] = nodes[con1];
	edges[i].connected[1] = nodes[con2];
	edges[i].weight = w;
}

void DOTGraph::parseDOT() {

	int i = 0;
	const int fileLines = 191;
	string fileStrings[fileLines];
		

	ifstream inFile("random64_4_1485816605.dot", ios::in);
	if (!inFile)
		cout << "Error loading file" << endl;
	else
	{
		inFile.ignore(80, '0[');
		while (!inFile.eof() && i < fileLines) {
			getline(inFile, fileStrings[i]);
			i++;
		}
		
		inFile.close();
		cout << endl << "Finished with file!" << endl;

		string tempS = "";
		int temp1 = 0, temp2 = 0;
		for (i = 0; i < fileLines; i++) {
			
			stringstream ss(fileStrings[i]);
			tempS = "";
			
			if (fileStrings[i].at(2) != '-') {
				for (int l = 0; l < 3; l++) {
					getline(ss, tempS, '"');
				}
				getline(ss, tempS, ',');
				temp1 = stoi(tempS);
				getline(ss, tempS, '"');
				temp2 = stoi(tempS);
				setNodePos(temp1, temp2);
			}

			else
			{
				getline(ss, tempS, '-');
				temp1 = stoi(tempS);
				getline(ss, tempS, '-');
				getline(ss, tempS, ' ');
				temp2 = stoi(tempS);
				for (int t = 0; t < 4; t++) {
					getline(ss, tempS, '"');
				}
				setEdge(temp1, temp2, stoi(tempS));
			}
		}
	}

}

Node DOTGraph::getNode(int i) {
	return nodes[i];
}

void Node::getNeighbours(DOTGraph graph, Node n[], int w[]) {
	int i = 0, id = 0;
	while ((i < 4) && (id < 128)) {
		if (graph.edges[id].connected[0].value == value) {
			/*graph.neighbours[i]*/ n[i] = graph.edges[id].connected[1];
			w[i] = graph.edges[id].weight;
			cout << "Node " << value << " has a neighbouring TO node of " << n[i].value << " with travel weight " << graph.edges[id].weight << endl;
			i++;
		}
		else if (graph.edges[id].connected[1].value == value) {
			/*graph.neighbours[i]*/ n[i] = graph.edges[id].connected[0];
			cout << "Node " << value << " has a neighbouring FROM node of " << /*graph.neighbours*/n[i].value << " with travel weight " << graph.edges[id].weight << endl;
			i++;
		}
		id++;
	}
}
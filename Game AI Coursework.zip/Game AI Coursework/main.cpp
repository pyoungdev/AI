#include <iostream>
#include <unordered_map>
#include <unordered_set>
#include <array>
#include <vector>
#include <utility>
#include <queue>
#include <functional>
#include "DOTGraph.h"
//#include "a_star_implementation.hpp"

using std::unordered_map;
using std::vector;
using std::queue;
using std::priority_queue;
using std::pair;

//template<typename L>
//struct Graph {
//	typedef L Location;
//	typedef typename vector<Location>::iterator iterator;
//	unordered_map<Location, vector<Location> > edges;
//
//	inline const vector<Location>  neighbors(Location id) {
//		return edges[id];
//	}
//};
//
//template<typename T, typename Number = int>
//struct PriorityQueue {
//	typedef pair<Number, T> PQElement;
//	priority_queue<PQElement, vector<PQElement>,
//		std::greater<PQElement >> elements;
//
//	inline bool empty() { return elements.empty(); }
//
//	inline void put(T item, int priority) {
//		elements.emplace(priority, item);
//	}
//
//	inline T get() {
//		T best_item = elements.top().second;
//		elements.pop();
//		return best_item;
//	}
//};
//
//template<typename Graph>
//void a_star_search
//(Graph graph, typename Graph::Location start, typename Graph::Location goal, unordered_map<typename Graph::Location, typename Graph::Location>& came_from, unordered_map<typename Graph::Location, int>& cost_so_far)
//{
//	typedef typename Graph::Location Location;
//	PriorityQueue<Location> frontier;
//	frontier.put(start, 0);
//
//	came_from[start] = start;
//	cost_so_far[start] = 0;
//
//	int count = 0;
//	while (!frontier.empty()) {
//		count++;
//		auto current = frontier.get();
//
//		if (current == goal) {
//			break;
//		}
//
//		for (auto next : graph.neighbors(current)) {
//			int new_cost = cost_so_far[current] + graph.cost(current, next);
//			if (!cost_so_far.count(next) || new_cost < cost_so_far[next]) {
//				cost_so_far[next] = new_cost;
//				int priority = new_cost + heuristic(next, goal);
//				frontier.put(next, priority);
//				came_from[next] = current;
//			}
//		}
//	}
//	std::cout << count << "\n";
//}




void a_star(DOTGraph graph, int start_node, int end_node/*, unordered_map<Node, Node>& came_from, unordered_map<Node, int>& cost_so_far*/) {

	/*priority_queue<Node, vector<Node>, std::greater<Node>> frontier;
	PriorityQueue<Node> frontier;
	Node start = graph.getNode(start_node);
	Node neighbours[4];
	frontier.push(start, 0);

	came_from[start] = start;
	cost_so_far[start] = 0;

	int count = 0;
	while (!frontier.empty()){
		count++;
		Node current = frontier.get();

		if (!(current.getPosition().equals(graph.getNode(end_node).getPosition()))) {
			break;
		}
		
		current.getNeighbours(graph, neighbours);

		for (Node next : neighbours) {
			int new_cost = cost_so_far[current] + graph.cost(current.next)
		}

*/



	Node start = graph.getNode(start_node);
	Node end = graph.getNode(end_node);
	Node current = start;
	int i = 0;
	Node neighbours[4];
	int nweights[4];
	//unordered_map<Position, int> cost_so_far;

	//int keki = 0;
	while (!(current.getPosition().equals(end.getPosition()))) {
		current.getNeighbours(graph, neighbours, nweights);
		for (Node n : neighbours) {
			//std::cout << cost_so_far[current.getPosition()];
			//int new_cost = cost_so_far[current.getPosition()] + nweights[i];
		}
		current = end;
	}
	

}


int main() {

	DOTGraph dot;
	dot.parseDOT();

	priority_queue<Node, vector<Node>, std::greater<>> pq;
	//unordered_map<Node, Node> came_from;
	//unordered_map<Node, int> cost_so_far;
	//Node current;
	//while (current.getPosition().equals(graph )
	//for (int i = 0; i < 64; i++) {
	//	current = dot.getNode(i);
	//	current.getNeighbours(dot, dot.neighbours);
	//	dot.getNeighbours(current);
	//}

	a_star(dot, 0, 60);//, came_from, cost_so_far);

	std::cin.get();

	return 0;
}